#!/usr/bin/python3
from setuptools import setup, find_packages
setup(
        name='jupiter',
        version='1.0.6',
        packages=find_packages(),
        author='Fred Monster',
        author_email='hezhiyuan_tju@163.com',
        url='',
        license='LICENSE',
        description='None'
        )
