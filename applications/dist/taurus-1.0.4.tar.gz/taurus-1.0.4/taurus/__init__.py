__version__ = '1.0.4'
__all__ = ['model', 'news_downloader', 'news_resource']
