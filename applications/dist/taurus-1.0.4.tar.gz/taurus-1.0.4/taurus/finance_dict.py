#!/usr/bin/python3

__version__ = 1


def test():
    pass
