__all__ == []

'''
1. relative capital
2. technical parameters
3. econemical analysis
3.1 financial report
3.2 news emotion
4. Fourier transform filter
5. ARIMA
6. stacked autoencoders
7. deep learning unsupervised
'''
