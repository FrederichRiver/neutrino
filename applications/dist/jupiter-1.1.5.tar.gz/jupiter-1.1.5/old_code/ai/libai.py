#!/usr/bin/python3
"""
Verfasst im Feb 21, 2019
"""

__author__ = 'Friederich Fluss'
__version__ = '1.0.1-beta'


