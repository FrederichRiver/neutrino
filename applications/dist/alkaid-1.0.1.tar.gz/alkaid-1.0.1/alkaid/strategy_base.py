#!/usr/bin/python3


class strategyBase(object):
    def __init__(self):
        pass

    def _get_data(self):
        pass

    def _settle(self):
        pass


if __name__ == "__main__":
    pass
