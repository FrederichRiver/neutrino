#!/usr/bin/python3


class Fomalhaut(object):
    pass
