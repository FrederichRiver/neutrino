#!/usr/bin/python3


class dataViewBase(object):
    def __init__(self):
        pass

    def get_baseline_data(self, stock_code='SH000300'):
        pass


if __name__ == "__main__":
    from dev_global.env import VIEWER_HEADER
