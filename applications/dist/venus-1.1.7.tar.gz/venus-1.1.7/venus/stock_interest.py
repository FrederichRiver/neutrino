#!/usr/bin/python3
import numpy as np
import pandas as pd
import requests
import time
from dev_global.env import CONF_FILE, GLOBAL_HEADER
from jupiter.utils import ERROR, read_url
from lxml import etree
from venus.stock_base import StockEventBase
from venus.form import formInterest


__version__ = '1.1.2'


class EventInterest(StockEventBase):
    def create_interest_table(self):
        create_table_from_table(
                "stock_interest",
                formInterest.__tablename__,
                self.mysql.engine)

    def record_interest(self):
        self.fetch_all_stock_list()
        for stock_code in self.stock_list:
            # stock code format: SH600000
            try:
                t = Thread(
                    target=self.sub_insert_interest_into_sql,
                    args=(stock_code,),
                    name=stock_code,
                    daemon=True)
                t.start()
                self.sub_insert_interest_into_sql(stock_code)
                time.sleep(1)
            except Exception:
                ERROR(f"Error while recording interest of {stock_code}")

    def sub_insert_interest_into_sql(self, stock_code):
        tab = self.resolve_table(stock_code)
        tab.replace(['--'], np.nan, inplace=True)
        tab.to_sql(
            'test_interest', self.mysql.engine.connect(),
            if_exists="append", index=True
            )

    def _resolve_dividend(self, stock_code):
        # fetch data table
        _, url = read_json('URL_fh_163', CONF_FILE)
        url = url.format(stock_code[2:])
        content = requests.get(url, timeout=3)
        html = etree.HTML(content.text)
        table = html.xpath(
            "//table[@class='table_bg001 border_box limit_sale']")
        share_table = table[0].xpath(".//tr")
        table_name = f"{stock_code}_interest"
        dt = DataLine()
        # resolve the data table
        for line in share_table:
            data_line = line.xpath(".//td/text()")
            if len(data_line) > 6:
                data_key, sql = dt.resolve(data_line, table_name)
                query = (f"SELECT * from {table_name} where "
                         f"report_date='{data_key}'")
                result = self.mysql.session.execute(query).fetchall()
                if not result:
                    self.mysql.session.execute(sql)
                    self.mysql.session.commit()

    def resolve_table(self, stock_code):
        import time
        url = read_url('URL_fh_163', CONF_FILE)
        url = url.format(stock_code[2:])
        result = pd.read_html(
            url, attrs={'class': 'table_bg001 border_box limit_sale'})
        tab = result[0]
        tab.columns = [
            'report_date', 'year', 'bonus', 'increase', 'dividend',
            'record_date', 'xrdr_date', 'share_date']
        tab.set_index('report_date', inplace=True)
        tab['stock_code'] = stock_code
        return tab

    def insert_interest_to_sql(self, df):
        for index, row in df.iterrows():
            sql = (
                "INSERT into test_interest ("
                "report_date,year,bonus,increase,dividend,record_date,"
                "xrdr_date,share_date) "
                "VALUES "
                f"('{index}',{str2number(row['year'])},{str2number(row['bonus'])},"
                f"{str2number(row['increase'])},{str2number(row['dividend'])},"
                f"'{str2number(row['record_date'])}','{str2number(row['xrdr_date'])}',"
                f"'{str2number(row['share_date'])}')"
            )
            try:
                self.mysql.engine.execute(sql)
            except Exception:
                print(Exception)


def str2number(in_str):
    import re
    if isinstance(in_str, str):
        in_str = in_str.replace(',', '')
        f = re.search(r'(\-|\+)?\d+(\.[0-9]+)?', in_str)
        d = re.match(r'\d{4}\-\d{2}\-\d{2}', in_str)
        if d:
            result = in_str
        elif f:
            # print(in_str) 
            try:
                result = float(f[0])
            except Exception:
                result = 'NULL'
        else:
            result = None
    elif isinstance(in_str, int):
        result = in_str
    elif isinstance(in_str, float):
        result = in_str
    else:
        result = None
    return result


if __name__ == "__main__":
    from dev_global.env import GLOBAL_HEADER
    import numpy as np
    stock_code = 'SH601818'
    event = EventInterest(GLOBAL_HEADER)
    tab = event.resolve_table(stock_code)
    # tab.replace(['--'], np.nan, inplace=True)
    event.insert_interest_to_sql(tab)
    """
    tab.to_sql(
            name='stock_interest', con=event.mysql.engine.connect(),
            if_exists="append", index=True
            )
    """
    """
    content = requests.get(url, timeout=3)
    html = etree.HTML(content.text)
    table = html.xpath(
            "//table[@class='table_bg001 border_box limit_sale']")
    share_table = table[0].xpath(".//tr")
    table_name = f"{stock_code}_interest"
    dt = DataLine()
    # resolve the data table
    for line in share_table:
        data_line = line.xpath(".//td/text()")
        if len(data_line) > 6:
            data_key, sql = dt.resolve(data_line, table_name)
            query = (f"SELECT * from {table_name} where "
                     f"report_date='{data_key}'")
            result = self.mysql.session.execute(query).fetchall()
            if not result:
                self.mysql.session.execute(sql)
                self.mysql.session.commit()
    """
