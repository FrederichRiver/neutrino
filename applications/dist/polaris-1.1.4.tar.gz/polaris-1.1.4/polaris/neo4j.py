#!/usr/bin/python3
from neo4j.v1 import GraphDatabase
uri = "bolt://localhost:7687"
