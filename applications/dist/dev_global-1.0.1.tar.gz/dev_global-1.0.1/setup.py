#!/usr/bin/python3
from setuptools import setup, find_packages
setup(
        name='dev_global',
        version='1.0.1',
        packages=['dev_global'],
        author='Fred Monster',
        author_email='hezhiyuan_tju@163.com',
        url='',
        license='LICENSE',
        description='None'
        )
