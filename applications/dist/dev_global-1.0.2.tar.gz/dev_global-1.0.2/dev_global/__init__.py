__version__ = '1.0.2'

# v1.0.1: Released.
# v1.0.2: Add Viewer account used for reading only.
