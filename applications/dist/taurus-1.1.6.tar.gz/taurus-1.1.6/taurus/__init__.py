__version__ = "1.1.6"
__all__ = ['model', 'news_downloader', 'news_resource', 'finance_dict']

# v1.1.6: Create newsSpiderBase metaclass, neteaseNewsSpider is a base on it.