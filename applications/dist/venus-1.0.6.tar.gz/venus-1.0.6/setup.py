#!/usr/bin/python3
from setuptools import setup, find_packages
setup(
        name='venus',
        version='1.0.6',
        packages=['venus'],
        author='Fred Monster',
        author_email='hezhiyuan_tju@163.com',
        url='',
        license='LICENSE',
        description='None'
        )
