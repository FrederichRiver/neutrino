#!/usr/bin/python3
import datetime
import functools
import pandas as pd
from dev_global.env import TIME_FMT
from polaris.mysql8 import mysqlBase
from venus.stock_base import StockEventBase
from jupiter.utils import data_clean, set_date_as_index


class financeBase(StockEventBase):
    def get_finance_value(self, stock_code, table_name, value_name, value_alias):
        """
        General query function
        """
        df = self.mysql.condition_select(
            table_name, f"report_period,{value_name}",
            f"stock_code='{stock_code}'")
        result = pd.DataFrame.from_dict(df)
        result.columns = ['date', value_alias]
        result = data_clean(result)
        result = set_date_as_index(result)
        return result

    def get_total_asset(self, stock_code):
        """
        return total asset.
        """
        result = self.get_finance_value(
            stock_code,
            'balance_sheet', 'r1_assets', 'total_asset')
        return result

    def get_total_liability(self, stock_code):
        """
        return total liability.
        """
        result = self.get_finance_value(
            stock_code,
            'balance_sheet', 'r4_liability', 'total_liability')
        return result

    def get_debt_2_asset_ratio(self, stock_code):
        result = self.get_finance_value(
            stock_code,
            'balance_sheet', 'r1_assets,r4_liability', ('total_asset', 'total_liability'))
        return result


if __name__ == "__main__":
    from dev_global.env import GLOBAL_HEADER
    event = financeBase(GLOBAL_HEADER)
    df = event.get_total_asset("SH601818")
    df = event.get_debt_2_asset_ratio("SH601818")
    print(df.head(5))
