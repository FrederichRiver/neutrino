#!/usr/bin/python3


class tradeDate(object):
    pass